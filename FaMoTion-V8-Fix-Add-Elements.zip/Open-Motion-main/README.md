<h1 align="center">Open Motion</h1>

<p align="center">
  <img
    src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/Proyek Baru 45 [D19F673].png"
    width="150"
    alt="Open Motion Logo"
  />
</p>

<p align="center">
  <strong>FaMoTion — browser-based motion graphics and video editor.</strong>
</p>

<p align="center">
  <a href="https://hada45.github.io/Open-Motion/">Launch Open Motion</a>
  ·
  <a href="LICENSE">MIT License</a>
</p>

<p align="center">
  <img src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/Home.jpg" width="18%" alt="Open Motion Home" />
  <img src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/Timeline.jpg" width="18%" alt="Open Motion Timeline" />
  <img src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/Camera%20transform.jpg" width="18%" alt="Open Motion Camera Transform" />
  <img src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/Curve%20editor.jpg" width="18%" alt="Open Motion Curve Editor" />
  <img src="https://raw.githubusercontent.com/Hada45/Open-Motion/refs/heads/Asset/vector.jpg" width="18%" alt="Open Motion Vector Editor" />
</p>

## Project Status

**🟨 PROTOTYPE / WORK IN PROGRESS**

Open Motion is still under active development and is **not production-ready yet**.
Features, project formats, UI behavior, and internal systems may continue to change.

---



---

## Try Open Motion

Open Motion currently runs directly in a modern web browser:

### [▶ Launch Open Motion](https://hada45.github.io/Open-Motion/)

**Recommended browser:** Google Chrome.

Some features may not work correctly in other browsers.

No installation, build step, or development server is required.

---

## About Open Motion

**Open Motion** is a free and open-source browser-based animation and video
editing project designed with a strong focus on mobile workflows.

The project currently focuses on keyframe animation, vector editing,
layer-based editing, 3D transforms, timeline controls, and experimental
high-performance rendering.

More advanced motion graphics and visual effects features are still under
active development.

---

## Features

### ⌨️ Keyframe Animation

Animate layer properties using timeline-based keyframes with interpolation
controls.

### 📈 Curve & Easing Editing

Fine-tune animation timing using easing controls and curve editing tools.

### ✒️ Vector Path Editing

Create and edit vector paths with anchors, Bézier handles, point insertion,
open and closed paths, and touch-oriented editing controls.

### 🧭 3D Transform Controls

Work with position and rotation in 3D space, including camera-oriented
transform workflows.

### 🧱 Layer-Based Editing

Build compositions using multiple editable layers with timeline controls,
visibility, ordering, and contextual property editing.

### 🎚️ Timeline Editing

Control layer timing, keyframes, playback position, duration, and animation
properties through the timeline interface.

### ⚡ Rendering & Playback

Open Motion includes experimental rendering and playback systems focused on
performance, GPU acceleration, export quality, and mobile hardware.

### 📱 Mobile-First Interface

The editor is designed around touch interaction while remaining usable on
desktop browsers.

### 🌐 Browser Based

Open Motion currently runs directly in a modern web browser without requiring
a traditional installation or build process.

### 📲 Progressive Web App

Open Motion includes PWA support and can be installed from supported browsers
for a more app-like experience.

### 🆓 Free & Open Source

Open Motion is released as open-source software under the MIT License.

---

## In Development

Open Motion is still evolving. Areas under active development include:

- Motion graphics workflows
- Visual effects
- Rendering quality and performance
- Advanced vector editing
- 3D editing and camera workflows
- Export and media processing
- Timeline and keyframe tools
- Mobile editing experience
- Project management and persistence
- Browser compatibility



---

## Future Native Architecture

Open Motion is currently developed as a web-based application. This makes it
faster to experiment with new ideas, test editor workflows, and iterate on
features while the project is still in an early stage.

In the future, there are plans to explore a native version of Open Motion,
including an Android application, once suitable native technologies are mature
enough for the project.

### Opus Framework

Open Motion may use [Opus Framework](https://youtu.be/bB4_B7TCoMY?si=6yFhzkhmmRT1DMR5)
as one possible foundation for a future native version once it becomes publicly available.


## Technology

The current prototype is primarily built with:

- HTML
- CSS
- JavaScript
- Canvas
- WebGL
- Browser media APIs
- Progressive Web App technologies

The current prototype intentionally remains largely self-contained while
the architecture continues to evolve.

---

## Browser Compatibility

Google Chrome is currently the recommended browser for testing Open Motion.

Because Open Motion uses modern browser APIs for rendering, media processing,
GPU acceleration, fullscreen behavior, and local project storage, some features
may behave differently or may not yet work in other browsers.

Mobile Chrome is currently one of the primary development targets.

---

## Contributing

Contributions, testing, bug reports, ideas, and technical discussions are welcome.

Because Open Motion is still under active development, major parts of the
codebase, architecture, project format, and user interface may change.

If you find a bug or have an idea for an improvement, feel free to open an
Issue or contribute to the repository.

---

## License

Open Motion is licensed under the [MIT License](LICENSE).


## FaMoTion V1 additions

- FaMoTion branding in the app title and PWA manifest.
- Touch feedback for buttons, with reduced-motion support.
- Preset Studio: best-effort XML parsing, local preset library, and `.fmpreset.json` export.
- XML is processed locally in the browser; it is not uploaded.

### Preset compatibility status

The importer currently parses XML structure and records likely keyframe/effect nodes and attributes. It does **not** yet apply Alight Motion properties to live editor layers. Alight Motion project/preset schemas and effect implementations need representative sample files and explicit property mapping before full compatibility can be claimed.


## FaMoTion V2 effect expansion

- Adds 12 independently implemented native GPU effects: RGB Split Pro, Pixelate, Invert, Sepia, Posterize, Sharpen, Emboss, Mirror, Kaleidoscope, Film Grain, Threshold, and Duotone.
- Effects are registered in the native effect stack and expose editable parameters.
- Existing core effects and the Alight Motion import/shader compatibility path remain in place.
- This is not a claim of 1:1 parity with every proprietary Alight Motion effect. Imported AM effects still depend on the source project's effect definitions and renderer compatibility; unsupported effects must remain clearly reported.


## FaMoTion AM-style interface pass

- Rebranded the home header and PWA manifest to FaMoTion.
- Reworked the mobile home into a project-first dark editor layout.
- Removed the oversized promotional hero and shortcut dashboard from the main landing view.
- Applied a unified dark/purple treatment to the editor preview, timeline, and tool dock.
- This is an interface pass; editor feature parity with Alight Motion is not implied.


## FaMoTion effect gallery visual update

- Added category-aware mini visual previews to effect cards in the effect browser.
- Updated visible home/splash/PWA branding to FaMoTion where applicable.
- Preview tiles are CSS-generated visual examples; they are not claims that every effect renders identically.


## FaMoTion frame-accurate timing update

- Alight Motion XML import now normalizes project duration, layer boundaries, and imported keyframe times to the imported project's FPS frame grid.
- Imported FPS is preserved (clamped to the editor-supported 1–120 range).
- Layer ends round upward to avoid shortening imported clips; keyframes snap to the nearest frame.
- This improves timing alignment but does not guarantee perfect compatibility with every proprietary Alight Motion project/effect.


## FaMoTion V3 — Elements & Branding patch

- Fixed the Elemen object action: it now closes the add drawer and opens the vector pen tool instead of incorrectly redirecting to Templates.
- Added FaMoTion-branded PWA icons and manifest metadata using the supplied logo artwork.
- The element action currently starts vector creation; reusable element library/import-export remains a separate follow-up feature.

### FaMoTion V4 Object Tools add-on

The V4 package adds an Object Tools button to the selected layer inspector. Transform shortcuts create keyframes at the current playhead. The local **Simpan ke Elemen Saya** shelf is browser-local (not cloud-synced). Clipping Mask remains disabled and universal Outline conversion is not yet implemented.

### FaMoTion V5 interface update
The V5 update adds a dark purple Alight Motion-inspired interface pass across the project hub, editor, timeline, keyframe markers, inspector drawers, and graph editor, plus Android safe-area and touch-feedback refinements. Existing Open Motion engine behavior remains the foundation; exact Alight Motion parity is not implied.
